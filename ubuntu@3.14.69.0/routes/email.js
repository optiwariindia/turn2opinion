const EMail ={
    isValid:function (email){
        return true;
    }
}
module.exports = EMail;